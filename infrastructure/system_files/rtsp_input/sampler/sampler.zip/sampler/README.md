# Instrucciones



## Video file
- Guardar el archivo de video en la carpeta videos
- Modificar la fila comentada con "#video source" con el path del video emepzando con ./videos. Ejemplo ./videos/se_quema_todo.mp4. GUARDAR.
- Ejecutar en la cmd:
<code>
sh ./run.sh
</code>

## RTSP
- Modificar la fila comentada con "#video source" con la URL de la RTSP. GUARDAR.
- Ejecutar en la cmd:
<code>
sh ./run.sh
</code>


## Comentarios
La primera vez correrlo tal cual esta, porque tiene que armar la imagen.
Una vez que lo haga no hace falta hacerlo nuevamente. 
Se puede comentar la primer linea de <em>run.sh</em> para que no la cree más.